# Настройки

- Название и тексты: `index.html`.
- Цена: сейчас указана в `index.html` и `payment.html`; меняйте согласованно.
- Цвета: переменные в начале `styles.css`.
- Контакт поддержки и реквизиты: заполните `contacts.html`, `privacy.html`, `terms.html`, `refund.html`.
- Backend URL, Telegram ID и платёжные секреты не добавляйте в публичный JavaScript. Храните секреты только на серверной платформе.
