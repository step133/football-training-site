create extension if not exists pgcrypto;
create table if not exists public.products (id text primary key, title text not null, price_minor integer not null check(price_minor>0), currency text not null, active boolean not null default true);
insert into public.products(id,title,price_minor,currency,active) values('home-ball-training','Домашние тренировки с мячом',100000,'RUB',true) on conflict(id) do nothing;
create table if not exists public.orders (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, product_id text not null references public.products(id), amount_minor integer not null, currency text not null, status text not null default 'pending' check(status in ('pending','paid','failed','cancelled','refunded')), provider_payment_id text unique, telegram_invite_created_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
alter table public.products enable row level security; alter table public.orders enable row level security;
create policy "Read active products" on public.products for select using(active=true);
create policy "Read own orders" on public.orders for select to authenticated using(auth.uid()=user_id);
-- No client write policy for orders: create/update only in server functions.
