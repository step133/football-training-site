# Backend scaffold

Supabase (Auth, Postgres, Edge Functions) is one possible backend path. This archive includes a starter schema and implementation requirements, not ready-to-deploy payment functions. Finish and test the server functions before connecting a real payment provider.
